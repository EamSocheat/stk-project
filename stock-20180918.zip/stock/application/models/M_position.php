<?php
	class M_position extends CI_Model{
		
		function __construct() 
		{
        	parent::__construct();
        	
    	}

    	function select(){
  
        	$this->db->select('*');
        	$this->db->from('tbl_position');
        	$this->db->order_by("com_id", "desc");
        	return $this->db->get()->result();;
		}

		public function update($id,$data){
			$this->db->where('com_id', $id);
			$this->db->update('tbl_position', $data);
		}
		
		public function insert($data){
			$this->db->insert('tbl_position',$data);
			return $this->db->insert_id();
		}
		

    }