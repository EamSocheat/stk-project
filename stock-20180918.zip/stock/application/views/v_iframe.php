
<!--  -->
<iframe id="ifameStockForm" src="" style="display: none;    width: 100%;overflow: hidden;height: 100%;border: none;"></iframe>
<!--  -->

<!-- modal add edit-->
<form id="frmAddEdit" action="post" method="#">
<div class="modal fade" id="modalMd">
  <div class="modal-dialog modal-md">
    <div class="modal-content" id="modalMdContent">
      
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
</form>
<!-- /.modal -->

